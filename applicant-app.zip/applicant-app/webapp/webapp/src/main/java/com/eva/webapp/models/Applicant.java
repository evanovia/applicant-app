package com.eva.webapp.models;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "applicants")
public class Applicant {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int id;

    @Column(name = "name", nullable = false) // Sesuaikan dengan kolom 'name'
    private String name;

    @Column(name = "dob", nullable = false) // Sesuaikan dengan kolom 'dob'
    private Date dob;

    @Column(name = "position", nullable = false) // Sesuaikan dengan kolom 'position'
    private String position;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
}
