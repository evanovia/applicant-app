package com.eva.webapp.repositories;

import com.eva.webapp.models.Applicant;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ApplicantRepository extends JpaRepository<Applicant, Integer> {

    List<Applicant> findByName(String name);

    List<Applicant> findByPosition(String position);
}
