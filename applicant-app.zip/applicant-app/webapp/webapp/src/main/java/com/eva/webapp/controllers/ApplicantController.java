package com.eva.webapp.controllers;

import org.springframework.ui.Model; // Ubah ini ke import yang benar
import com.eva.webapp.repositories.ApplicantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/applicants")
public class ApplicantController {

    @Autowired
    private ApplicantRepository applicantRepo;

    @GetMapping({"", "/"})
    public String getApplicants(Model model) {
        var applicants = applicantRepo.findAll(Sort.by(Sort.Direction.DESC, "id"));
        model.addAttribute("applicants", applicants);

        return "applicants/index";
    }
}
